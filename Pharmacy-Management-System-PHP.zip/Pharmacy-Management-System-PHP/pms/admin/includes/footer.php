<footer class="footer">
        <div class="row align-items-center justify-content-xl-between">
          <div class="col-xl-6">
      
          </div>
          <div class="col-xl-6">
            <h4 style="text-align: right;">Pharmacy Management System</h4>
</div>
          </div>
        </div>
      </footer>